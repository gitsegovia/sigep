--
-- PostgreSQL database dump
--

-- Started on 2009-09-15 08:48:35 VET

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- TOC entry 4732 (class 0 OID 34528)
-- Dependencies: 3478
-- Data for Name: cfpd01_grupo; Type: TABLE DATA; Schema: public; Owner: sisap
--

ALTER TABLE cfpd01_grupo DISABLE TRIGGER ALL;

COPY cfpd01_grupo (cod_grupo, descripcion, concepto) FROM stdin;
3	RECURSOS	Son los medios de financiamiento que la República y demás instituciones del sector público obtienen, en uso de sus competencias legales y de las funciones que le son propias, relacionadas con la tributación, operaciones de compra y venta, el endeudamiento, la disminución de activos y el aumento de pasivos. 
4	EGRESOS	Contemplan, además del crédito presupuestario como autorización para gastar que tiene la Administración Pública, las transacciones financieras constitutivas de los incrementos de activos y disminuciones de pasivos que ocurren en el transcurso del ejercicio económico-financiero. 
\.


ALTER TABLE cfpd01_grupo ENABLE TRIGGER ALL;

-- Completed on 2009-09-15 08:48:36 VET

--
-- PostgreSQL database dump complete
--


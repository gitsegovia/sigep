--
-- PostgreSQL database dump
--

-- Started on 2009-09-15 08:51:52 VET

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- TOC entry 4734 (class 0 OID 34507)
-- Dependencies: 3474
-- Data for Name: cfpd01_auxiliar; Type: TABLE DATA; Schema: public; Owner: sisap
--

ALTER TABLE cfpd01_auxiliar DISABLE TRIGGER ALL;

COPY cfpd01_auxiliar (cod_grupo, cod_partida, cod_generica, cod_especifica, cod_sub_espec, cod_auxiliar, descripcion, concepto) FROM stdin;
3	1	7	1	3	1	SUPERFICIAL SOBRE OTROS MINERALES (SALINAS)	IMPUESTOS GENERADOS POR LA CONCESION PARA LA EXPLOTACION DE LAS SALINAS UBICADAS EN EL TERRITORIO FALCONIANO
3	1	7	2	4	1	IMPUESTO DE EXPLOTACION SOBRE OTROS MINERALES (MINERALES NO METALICOS)	IMPUESTOS GENERADOS POR EL EXPLOTACION DE MINERALES NO METALICOS EN EL ESTADO FALCON
\.


ALTER TABLE cfpd01_auxiliar ENABLE TRIGGER ALL;

-- Completed on 2009-09-15 08:51:52 VET

--
-- PostgreSQL database dump complete
--

